#include"principale.h"

Principale::Principale()
{
    setFixedSize(1024,640);
    unLabel = new QLabel(this);
    //unBack = new QPixmap("C:/Qt/image/im.jpg");
    unLabel->setPixmap(*unBack);
    unLabel->setGeometry(0,0,1024,640);
    unBouton = new QPushButton("Clic ici pour choisir une image ",this);
    unBouton->setGeometry(100,50,150,50);
    connect(unBouton,SIGNAL(clicked()),this,SLOT(appui()));
    QDir ("chemin");
}
void Principale::appui()
{

    //QString chemin = QFileDialog::getOpenFileName(this,"c:","");
    QString chemin ="C:/Mazmouz Kamal/Projet pieces/euro.jpg";
    unBack = new QPixmap(chemin);
    unLabel->setPixmap(QPixmap (chemin).scaled(400,400));

}

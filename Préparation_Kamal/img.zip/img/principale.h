#ifndef PRINCIPALE_H
#define PRINCIPALE_H
#include<QtWidgets>
class Principale : public QMainWindow
{
    Q_OBJECT

    private :
        QLabel *unLabel;
        QPixmap *unBack;
        QPushButton *unBouton;

    public :
        Principale();

    private slots :
        void appui();
};

#endif // PRINCIPALE_H

#include<QApplication>
#include<QtWidgets>
#include"principale.h"

int main(int argc,char *argv[])
{
    QApplication app(argc,argv);
    Principale window;
    window.show();
    return app.exec();
}
